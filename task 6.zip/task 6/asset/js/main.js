 (function($){
 	"use strict";

 	jQuery(document).ready(function($){

		$(".homepage-slides.owl-carousel").owlCarousel({
			items: 1,
			nav: false,
			dots: true,
			loop: true,
			autoplay: false,
		})


 	})

 	jQuery(window).load(function(){

 	})
	

	

}(jQuery));
